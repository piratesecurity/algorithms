# interview_question_practice

I tried to solve the interview question given in this link in this project.

http://www.geeksforgeeks.org/google-interview-question-for-java-position/
